package relterm;

import exceptions.TypingException;
import exceptions.UnificationException;
import main.VariableGenerator;
import typeterm.RelationType;
import typeterm.Typeterm;

import java.util.List;
import java.util.Map;

public class Meet extends Relterm {
    private final Relterm left;
    private final Relterm right;
    private static final int precedence = 20;

    public Meet(Relterm left, Relterm right) {
        this.left = left;
        this.right = right;
    }

    @Override
    protected void type(VariableGenerator gen, Map<String, RelationType> env, List<RelationType> cons) throws TypingException {
        left.type(gen, env, cons);
        right.type(gen, env, cons);
        RelationType leftType = left.getType();
        RelationType rightType = right.getType();

        try {
            Map<String, Typeterm> subst = leftType.source.unify(rightType.source);
            leftType.target.unify(rightType.target, subst);
            env.forEach((var,type) -> type.substitute(subst));
            cons.forEach(type -> type.substitute(subst));
        } catch (UnificationException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public RelationType getType() {
        return new RelationType(left.getType().source,left.getType().target);
    }

    @Override
    public String toStringPrec(int prec) {
        String result = left.toStringPrec(precedence) + "\u2293" + right.toStringPrec(precedence);
        if (prec > precedence) result = "(" + result + ")";
        return result;
    }

}
