package typeterm;

import exceptions.UnificationException;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class TypeVariable extends Typeterm {
    private final String name;

    public TypeVariable(String name) {
        this.name = name;
    }

    @Override
    public String toStringPrec(int prec) {
        return name;
    }

    @Override
    public Set<String> variables() {
        Set<String> vars = new HashSet<>();
        vars.add(name);
        return vars;
    }

    @Override
    public Typeterm substitute(Map<String, Typeterm> subst) {
        return subst.getOrDefault(name, this);
    }

    @Override
    public void unify(Typeterm other, Map<String, Typeterm> unifier) throws UnificationException {
//        if (other.variables().contains(name)) {
//            throw new UnificationException("Variable already exists");
//        } else{
            unifier.keySet().forEach(var -> unifier.put(var, unifier.get(var).substitute(name, other)));
            unifier.put(name,other);
//        }
    }
}
