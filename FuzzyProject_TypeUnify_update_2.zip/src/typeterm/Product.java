package typeterm;

import exceptions.UnificationException;

import java.util.Map;
import java.util.Set;

public class Product extends Typeterm {
    private final Typeterm left;
    private final Typeterm right;
    private static final int precedence = 20;

    public Product(Typeterm left, Typeterm right){
        this.left = left;
        this.right = right;
    }

    @Override
    public String toStringPrec(int prec) {
        String result = left.toStringPrec(precedence) + "*" + right.toStringPrec(precedence);
        if (prec > precedence) result = "(" + result + ")";
        return result;
    }

    @Override
    public Set<String> variables() {
        Set<String> vars = left.variables();
        vars.addAll(right.variables());
        return vars;
    }

    @Override
    public Typeterm substitute(Map<String, Typeterm> subst) {
        Typeterm newLeft = left.substitute(subst);
        Typeterm newRight = right.substitute(subst);

        return new Product(newLeft, newRight);
    }

    @Override
    public void unify(Typeterm other, Map<String, Typeterm> unifier) throws UnificationException {
        if (other instanceof TypeVariable){
            other.unify(this, unifier);
        } else if (other instanceof Product otherProd){
            left.unify(otherProd.left, unifier);
            right.substitute(unifier).unify(otherProd.right.substitute(unifier),unifier);
        } else throw new UnificationException("Cannot unify " + this + " and " + other + ".");
    }
}
