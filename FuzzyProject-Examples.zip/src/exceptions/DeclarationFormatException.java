package exceptions;

public class DeclarationFormatException extends Error{
    public DeclarationFormatException(String errorMessage){
            super(errorMessage);
        }
}
