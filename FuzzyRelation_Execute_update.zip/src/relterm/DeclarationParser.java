package relterm;

import exceptions.DeclarationFormatException;
import exceptions.TypingException;
import typeterm.RelationType;
import typeterm.Typeterm;
import typeterm.TypetermParser;

import java.util.HashMap;
import java.util.Map;

public class DeclarationParser {
    private final ReltermParser reltermParser;
    private final TypetermParser typetermParser;

    public DeclarationParser(ReltermParser relparser, TypetermParser typeParser) {
        this.reltermParser = relparser;
        this.typetermParser = typeParser;
    }
//    Choice (R:A->A) : P(A) -> A = ε\R˘⊓ε˘
    public Declaration parseDeclaration(String dec){
        Declaration declaration = new Declaration();
        var decMap = declarationMap(dec);
        var typeMap = resultTypeMap(decMap.get("decRel"), typetermParser);

        declaration.name = decMap.get("name");

        Typeterm source = typeMap.get("source");
        Typeterm target = typeMap.get("target");
        declaration.resultType = new RelationType(source, target);

        declaration.vars = variablesMap(decMap.get("decVars"), typetermParser);
        declaration.t = reltermParser.parse(decMap.get("decTerm"));

        System.out.println(declaration);

        return declaration;
    }

    private Map<String, Typeterm> resultTypeMap(String decRel, TypetermParser typeparser) {
        Map<String, Typeterm> relTypeMap = new HashMap<>();

        String sourceStr = decRel.split("->")[0];
        String targetStr = decRel.split("->")[1];

        relTypeMap.put("source", typeparser.parse(sourceStr));
        relTypeMap.put("target", typeparser.parse(targetStr));
        return relTypeMap;
    }

    private Map<String, RelationType> variablesMap(String decVars, TypetermParser typeparser) {
        Map<String, RelationType>  varMap= new HashMap<>();

        String variable = decVars.split(":")[0];
        String secondPart = decVars.split(":")[1];

        Typeterm source = typeparser.parse(secondPart.split("->")[0]);
        Typeterm target = typeparser.parse(secondPart.split("->")[1]);

        varMap.put(variable, new RelationType(source, target));
        return varMap;
    }

    private Map<String, String> declarationMap(String dec) {
        declarationFormatChecker(dec);
        Map<String, String> decMap = new HashMap<>();
        dec = dec.replace(" ","");

        String firstPart = splitHelper(dec, ":", 0);
        String secondPart = splitHelper(dec, ":", 1);

        decMap.put("name", splitHelper(firstPart, "(", 0));
        decMap.put("decVars", splitHelper(firstPart, "(", 1).replace(")",""));
        decMap.put("decRel", splitHelper(secondPart, "=", 0));
        decMap.put("decTerm", splitHelper(secondPart, "=", 1));

        return decMap;
    }

    private String splitHelper(String dec, String deli, int pos) {
        int index = dec.contains(deli) ? dec.lastIndexOf(deli) : 0;
        if (pos == 1)
            return dec.substring(index+1);
        else
            return dec.substring(0, index);
    }

    private void declarationFormatChecker(String dec){
        if (delimiterCount(dec, ':') != 2 || delimiterCount(dec, '=') != 1
                || delimiterCount(dec, '(') < 1 || delimiterCount(dec, ')') < 1) {
            throw new DeclarationFormatException("Incorrect Declaration String Format");
        }
    }
    private long delimiterCount(String dec, char deli){
        return dec.chars().filter(ch -> ch == deli).count();
    }
}
