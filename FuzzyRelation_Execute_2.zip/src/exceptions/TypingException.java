package exceptions;

public class TypingException extends Exception{
    public TypingException(String errorMessage){
        super(errorMessage);
    }
}
