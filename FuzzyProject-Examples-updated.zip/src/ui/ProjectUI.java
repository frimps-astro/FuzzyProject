package ui;

import ui.utils.UIComponents;
import ui.utils.UIMethods;
import javax.swing.*;

import static ui.utils.UIConstants.*;

public class ProjectUI extends JFrame{

    JSplitPane jSplitPane = new JSplitPane();

    public ProjectUI(){
        setLocation(SCREENSIZE.width/6, SCREENSIZE.height/5);
        setTitle(STR."PROJECT: \{PROJECTNAME.toUpperCase()}");
        jSplitPane.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
        jSplitPane.setResizeWeight(0.6);

        jSplitPane.setLeftComponent(UIComponents.getInstance().projectUILeftPane());
        jSplitPane.setRightComponent(UIComponents.getInstance().projectUIRightPane(this));

        add(jSplitPane);
        setVisible(true);
        setSize(1090, 700);
        addWindowListener(UIMethods.getInstance().windowEvent());
    }
}
