package exceptions;

public class RelationException extends Exception{
    public RelationException(String errorMessage){
        super(errorMessage);
    }
}
