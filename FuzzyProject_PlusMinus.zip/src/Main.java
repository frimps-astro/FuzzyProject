import ui.UserInterface;

public class Main {
    public static void main(String[] args) {
//        String dec = "Choice (R:A->A, T:B->B) : P(A) -> A = ε\\R˘⊓ε˘";
//        Declaration declaration = DeclarationParser.getTypeParser().parse(dec);
//        System.out.println(declaration);
//        Project project = new Project();
//        project.setName("user");
//        project.setProject();
        UserInterface userInterface = UserInterface.getInstance();
    }
}
