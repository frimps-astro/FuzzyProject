package exceptions;

public class EmptyNodesException extends Exception{
    public EmptyNodesException(String errorMessage){
        super(errorMessage);
    }
}
