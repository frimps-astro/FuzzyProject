package relterm;

import exceptions.TypingException;
import exceptions.UnificationException;
import main.VariableGenerator;
import sets.Unit;
import typeterm.RelationType;
import typeterm.Typeterm;
import typeterm.UnitTerm;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Declaration {
    String name;
    RelationType resultType;
    Map<String, RelationType> vars;
    Relterm t;

    public RelationType type() throws TypingException {
        VariableGenerator gen = new VariableGenerator();
        List<RelationType> cons = new ArrayList<>();
        t.type(gen, vars, cons);
        RelationType tType = t.getType();

        try {
            Map<String, Typeterm> subst = tType.source.matchTo(resultType.source);
            vars.forEach((var,type) -> type.substitute(subst));
            cons.forEach(type -> type.substitute(subst));

            cons.forEach(type -> {
                if (!vars.containsValue(type)){
                    UnitTerm unitTerm = new UnitTerm(gen.newVarName());
                    cons.replaceAll(t -> unitTerm);
                }
            });
        } catch (UnificationException e) {
            throw new RuntimeException(e);
        }

        return t.getType();
    }
}
