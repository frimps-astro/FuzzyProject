package xmlutils;

public interface XMLObject {
	public String toXMLString();
}