package exceptions;

public class UnificationException extends Exception{
    public UnificationException(String errorMessage){
        super(errorMessage);
    }
}
