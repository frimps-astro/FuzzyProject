package ui.utils;

import exceptions.OperationExecutionException;
import relations.Relation;
import relterm.Declaration;
import relterm.DeclarationParser;
import storage.BasisStorage;
import storage.HeytingAlgebraStorage;
import storage.RelationStorage;
import storage.SetObjectStorage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;

import static ui.utils.UIConstants.INTERFACES;
import static ui.utils.UIConstants.LISTBGCOLOR;


public class UIMethods {
    public static UIMethods UIMETHODS = null;

    public static UIMethods getInstance() {
        if (UIMETHODS == null) UIMETHODS = new UIMethods();
        return UIMETHODS;
    }

    public boolean createSetObject(int selectedIndex, String component1, String component2) {
        boolean created = false;
        if (component1 != null && component2 != null){
            try {
                switch (selectedIndex){
                    case 1 -> SetObjectStorage.getInstance()
                            .createSumSetObject(component1+"+"+component2, component1, component2);
                    case 2 -> SetObjectStorage.getInstance()
                            .createProductSetObject(component1+"x"+component2, component1, component2);
                    case 3 -> SetObjectStorage.getInstance()
                            .createPowerSetObject(component1+"^"+component2, component2, component1);
                }
                return !created;
            } catch (OperationExecutionException e) {
                UIDialogs.getInstance().notifyDialog(formatNotification(e.getMessage().split(":")[1]));
            }
        }
        return created;
    }

    public void executeButtonAction(JComboBox<String> selectedRel, String dec) {
//        try {
            if (!dec.isEmpty()){
                if (selectedRel.getSelectedIndex() != 0) {
                    String rel = selectedRel.getSelectedItem().toString();
                    Relation relation = RelationStorage.getInstance().load(rel);
                    LinkedHashMap<String, Relation> relsMap = new LinkedHashMap<>();
                    relsMap.put(rel, relation);

                    Declaration declaration = DeclarationParser.getTypeParser().parse(dec);
                    Relation executedDec = declaration.execute(relsMap, new HashMap<>(), relation.getAlgebra());
                    System.out.println(executedDec);
                } else {
                    UIDialogs.getInstance().notifyDialog("Please select a relation");
                }
            } else {
                UIDialogs.getInstance().notifyDialog("Please enter a Declaration");
            }
//        } catch (Exception e){
//            System.out.println(e.getStackTrace());
////            UIDialogs.getInstance().notifyDialog(formatNotification(e.getMessage().split(":")[1]));
//        }
    }

    private String formatNotification(String note) {
        String newNote = "<html>";
        System.out.println(note.length());
        if (note.length() > 40) {
            newNote += note.substring(0, 40);
            newNote += "...<br>"+note.substring(40)+"</html>";
            return newNote;
        }
        return note;
    }

    public String[] readDataList(String path){
        File file = new File(path);
        String[] projects = file.list((current, name) -> new File(current, name).isDirectory());

        return projects;
    }

    public WindowAdapter windowEvent() {
       return new WindowAdapter() {
           @Override
           public void windowOpened(WindowEvent e) {
               var window = e.getWindow().getClass();
               System.out.println("opened: "+ window.getSimpleName());
               INTERFACES.put(window.getSimpleName(), (JFrame) e.getComponent());
               super.windowOpened(e);
           }

            @Override
            public void windowClosing(WindowEvent e) {
                String window = e.getWindow().getClass().getSimpleName();
                System.out.println("closed: "+window);
                INTERFACES.remove(window);
                super.windowClosed(e);
            }
        };
    }
}
