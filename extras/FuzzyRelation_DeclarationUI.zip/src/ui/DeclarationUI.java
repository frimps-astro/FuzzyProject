package ui;


import relations.Relation;
import storage.RelationStorage;
import ui.utils.UIMethods;

import javax.swing.*;
import java.awt.event.*;
import java.util.LinkedHashMap;

import static ui.utils.UIConstants.BUTTONHEIGHT;
import static ui.utils.UIConstants.BUTTONWIDTH;

public class DeclarationUI extends JFrame {
    JTextField decI, varCountI;
    JLabel decl, varL;
    JButton executeB;
    int xaxis = 50, yaxis = 50, height = 30;

    public DeclarationUI() {
        setTitle("Declaration Execution");
        createComponents();

        setSize(600, 500);
        setLocationRelativeTo(null);
        setLayout(null);
        setVisible(true);
        addWindowListener(UIMethods.getInstance().windowEvent());
    }

    private void createComponents() {
        decl = new JLabel("Declaration:");
        decl.setBounds(xaxis, yaxis, 120, height);

        decI = new JTextField();
        decI.setBounds(xaxis * 3, 50, 350, height);


        varL = new JLabel("Relation:");
        varL.setBounds(xaxis, yaxis * 2, 120, height);

        JComboBox<String> relsBox = new JComboBox<String>(RelationStorage.getInstance().getEntityNames());
        relsBox.insertItemAt("--select relation--", 0);
        relsBox.setSelectedIndex(0);
        relsBox.setBounds(xaxis * 3, yaxis * 2, 200, height);

        executeB = new JButton("Execute");
        executeB.setBounds(xaxis * 3, yaxis*3, BUTTONWIDTH, BUTTONHEIGHT);
        executeB.addActionListener(e-> UIMethods.getInstance().executeButtonAction(relsBox, decI.getText()));
        add(decI);
        add(decl);
        add(varL);
        add(relsBox);

        add(executeB);
    }
}