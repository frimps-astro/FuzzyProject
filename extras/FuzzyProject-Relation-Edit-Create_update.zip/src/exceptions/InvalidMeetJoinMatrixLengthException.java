package exceptions;

public class InvalidMeetJoinMatrixLengthException extends Exception{
    public InvalidMeetJoinMatrixLengthException(String errorMessage){
        super(errorMessage);
    }
}
