package exceptions;

public class InvalidXYvalueException extends Exception{
        public InvalidXYvalueException(String errorMessage) {
            super(errorMessage);
        }
}
